# Cookies Package
<p align="center">
  <a href="https://github.com/Callumgm/Github-View-Bot/graphs/commit-activity">
    <img src="https://img.shields.io/badge/maintained-no-critical?style=flat-square" alt="Maintained No" />
  </a>
  <img src="https://img.shields.io/badge/python-3.9.7-blue?style=flat-square" alt="Python 3.9.7" />
</p>

## About 
Decided to create a very simple yet very fast Github view bot (some requests dont get sent tho)

## Features
- Bot any raw link
- Code is obfused to stop skidders :)

## Install Instructions
1. Download or Gitclone this project
2. Make sure to ofc have `Python 3.9.7` downloaded & added to PATH on install
3. Run `Setup and Run.bat` to installed the needed requirements & run the file after finshed
4. Right link whatever u wanna make the bots view (image is best) and click `copy address` 
[Preview](https://cdn.discordapp.com/attachments/974672407765876800/975769188612325416/unknown.png) 
and paste into the view bot
5. Choose the amount of threads u wish to use, then just wait :)

## Change Log
### 25/06/2022
- Updated code to be more cleaner and faster


## Contact
Email - Callumgm20052005@gmail.com




